// const chalk = require('chalk')
// const chalktext = chalk.blue.inverse('Hello World!')
// console.log(chalktext)

// const validator = require('validator')

// const mail = validator.isEmail('shadandigixito.com')
// const cha = chalk.red.inverse(mail)
// console.log(cha)

// // yargs

// const yargs = require('yargs')
// const arg = yargs.command({
//     command: 'remove',
//     description: 'Are you sure for removing This',
//     handler: function(){
//         console.log('Remove Successfully')
//     } 
// }).argv
// console.log(arg)


// //JSON

// const fs = require('fs')

// // const dataJSON = {
// //     name: "Shadan",
// //      company: "Digixito",
// //      age: 23
// // }
// // fs.writeFileSync('data.json', dataJSON)
// const readData = fs.readFileSync('data.json').toString()
// const readJson = JSON.parse(readData)



// readJson.name = "Khaan"
// readJson.company = "Pvvt Ltd"

// const reWrite = JSON.stringify(readJson)
// fs.writeFileSync('data.json', reWrite)

// console.log(readJson)


// setTimeout(() => {
//     console.log("Hey dear Sorry For Late!!")
// }, 3000);

// setTimeout(() => {
// console.log("HEHEH")
// }, 2000)


// // setInterval( ()=>{
// //     console.log("okay dear")
// // }, 5000)

const path = require('path')

const express = require('express')

const app = express()

const homepage = path.join(__dirname, 'public')
app.use(express.static(homepage))


const aboutpage = path.join(__dirname, 'public/about.html')

app.use(express.static(aboutpage), ()=>{
    console.log("about page live now!")
})

app.get('/contact', (req,res)=>{
  res.send({
      url: 'public/about.html',
  })
})

app.listen(4444, ()=>{
    console.log('done')
})